#!/bin/sh

tgtadm --lld iscsi --op show --mode target
